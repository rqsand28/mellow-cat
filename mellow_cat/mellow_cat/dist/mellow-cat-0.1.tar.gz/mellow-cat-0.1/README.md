# mellow_cat/__init__.py

# Import the main function from the mellow_cat module
from .mellow_cat import main

# Define the package's API
__all__ = ['main']
